

def flip_observation(observation: list, n_pieces: int, n_spots: int) -> list:

    # First reverse the observation
    pos_obs = observation[:7]

    # Then flip the number of players based on the n_pieces variable
    flipped_obs = []

    for o in pos_obs:
        if o > n_pieces:
            flipped_obs.append(o - n_pieces)
        elif o > 0 and o <= n_pieces:
            flipped_obs.append(o + n_pieces)
        else:
            flipped_obs.append(o)
        
    flipped_obs = flipped_obs + list(observation[-4:])
    
    # Now the observation has been flipped
    return tuple(flipped_obs)

def flip_action(action: tuple, n_spots: int) -> tuple:
    # This takes in an action that is based on a flipped observation
    # It then reverses the flipped action into an ordinary action

    rev_board_indices = list(reversed(range(n_spots + 1)))

    flipped_action = (rev_board_indices[action[0]], rev_board_indices[action[1]])

    return flipped_action